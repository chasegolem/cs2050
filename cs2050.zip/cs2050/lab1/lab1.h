#ifndef _LAB1_H
#define _LAB1_H
// Function Prototypes
int getAverage(int array[], int size, float *result);
int sumPositive(int array[], int size, int *result);
int sumOdd(int array[], int size, int *result);
#endif
#include <stdio.h>
#include "lab1.h"

int main(void){
    int array[5] = {1, 2, 3, 4, 5};

    float average;
    int evenSum;
    int oddSum;

    getAverage(array, 5, &average);
    sumPositive(array, 5, &evenSum);
    sumOdd(array, 5, &oddSum);

    printf("average = %lf, evenSum = %d, oddSum = %d", average, evenSum, oddSum);
}
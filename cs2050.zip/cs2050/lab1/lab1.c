#include <stdio.h>
#include "lab1.h"

int getAverage(int array[], int size, float *result){
    printf("%lf\n", *result);
    if(size < 1) return 1;
    float count = 0.0;
    for(int i = 0; i < size; i++){
        count += array[i];
    }

    count /= size;
    result = &count;
    return 0;
}

int sumPositive(int array[], int size, int *result){
    printf("%d\n", *result);
    if(size < 1) return 1;
    int count = 0;
    for(int i = 0; i < size; i++){
        if(array[i] % 2 == 0){
            count += array[i];
        }
    }

    result = &count;
    return 0;
}

int sumOdd(int array[], int size, int *result){
    printf("%d\n", *result);
    if(size < 1) return 1;
    int count = 0;
    for(int i = 0; i < size; i++){
        if(array[i] % 2 == 1){
            count += array[i];
        }
    }

    result = &count;
    return 0;
}
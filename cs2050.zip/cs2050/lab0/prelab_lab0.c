#include <stdio.h>

int main(void){
    int size;
    int query;
    scanf("%d %d", &size, &query);

    int arr[size];
    for(int i = 0; i < size; i++){
        scanf("%d", &arr[i]);
    }

    int count = 0;
    for(int i = 0; i < size; i++){
        printf("arr[%d]: %d", i, arr[i]);
        if(arr[i] >= query) count++;
    }

    printf("matches: %d\n", count);
}
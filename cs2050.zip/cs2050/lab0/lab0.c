#include "lab0.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050, Fall 2023
 * Lab 0
 * 25 August 2023
*/

int countOccurrences(int size, int array[], int query){
    int count = 0;
    for(int i = 0; i < size; i++){
        if(array[i] == query) count++;
    }
    return count;
}
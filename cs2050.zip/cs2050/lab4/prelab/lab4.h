#ifndef _LAB4_H
#define _LAB4_H

typedef struct {
    int empID, jobType;
    float salary;
} Employee;

Employee * readEmployeeArray(FILE*);
Employee * getEmployeeByID(Employee *, int);
int setEmpSalary(Employee *, int, float);
int getEmpSalary(Employee *, int, float *);
int setEmpJobType(Employee *, int, int);
int getEmpJobType(Employee *, int, int *);

#endif
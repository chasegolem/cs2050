#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"

Employee * readEmployeeArray(FILE* file){
    int size;
    fscanf(file, "%d", &size);
    
    Employee* arr = malloc(size * sizeof(Employee));

    if(arr){
        for(int i = 0; i < size; i++){
            fscanf(file, "%d %d %f", &arr[i].empID, &arr[i].jobType, &arr[i].salary);
        }
    }

    return arr;
}

Employee * getEmployeeByID(Employee *arr, int empID){
    int i = 0;
    while(&arr[i]){
        if(arr[i].empID == empID){
            return &arr[i];
     	}
	i++;
    }
    return NULL;
}

int setEmpSalary(Employee *arr, int empID, float salary){
    Employee *e = getEmployeeByID(arr, empID);
    if(e){
        (*e).salary = salary;
        return 0;
    } else {
        return 1;
    }
    return 0;
}

int getEmpSalary(Employee *arr, int empID, float *salary){
    Employee *e = getEmployeeByID(arr, empID);
    if(e){
        *salary = (*e).salary;
        return 0;
    } else {
        return 1;
    }
    return 0;
}

int setEmpJobType(Employee *arr, int empID, int job){
    Employee *e = getEmployeeByID(arr, empID);
    if(e){
        (*e).jobType = job;
        return 0;
    } else {
        return 1;
    }
    return 0;
}

int getEmpJobType(Employee *arr, int empID, int *job){
    Employee *e = getEmployeeByID(arr, empID);
    if(e){
        *job = (*e).jobType;
        return 0;
    } else {
        return 1;
    }
    return 0;
}

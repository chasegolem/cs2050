#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"

int main(int argc, char *argv[]){
    FILE* file = fopen("data.file", "r");
    int size;
    int searchID;
    if(argv[1]) searchID = atoi(argv[1]);
    printf("searchID = %d\n", searchID);
    fscanf(file, "%d", &size);
    rewind(file);

    Employee *employees = readEmployeeArray(file);
    for(int i = 0; i < size; i++){
        printf("employee[%d] = [%d, %d, %f]\n", i, employees[i].empID, employees[i].jobType, employees[i].salary);
    }

    Employee *search = getEmployeeByID(employees, searchID);
    if(search){
        printf("search = [%d, %d, %f]\n", search->empID, search->jobType, search->salary);
    } else {
        printf("employee not found\n");
    }

    setEmpJobType(employees, searchID, 2);
    int newJobType;
    getEmpJobType(employees, searchID, &newJobType);
    printf("newJobType = %d\n", newJobType);
    setEmpSalary(employees, searchID, 123123123.123);
    float newSalary;
    getEmpSalary(employees, searchID, &newSalary);
    printf("newSalary = %f\n", newSalary);

    Employee *searchNew = getEmployeeByID(employees, searchID);
    if(search){
        printf("search = [%d, %d, %f]\n", searchNew->empID, searchNew->jobType, searchNew->salary);
    } else {
        printf("employee not found\n");
    }
}
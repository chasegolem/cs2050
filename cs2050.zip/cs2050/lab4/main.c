#include <stdio.h>
#include "lab4.h"

int main(void){
    FILE* file = fopen("data.file", "r");
    int arraySize;
    fscanf(file, "%d", &arraySize);
    printf("size = %d\n", arraySize);

    InventoryItem *items = makeArray(arraySize, sizeof(InventoryItem));
    printf("size = %d\n", getSize(items));
    for(int i = 0; i < arraySize; i++){
        fscanf(file, "%d %f %d %hd", &items[i].ID, &items[i].weight, &items[i].stockCount, &items[i].colors);
    }

    for(int i = 0; i < arraySize; i++){
        printf("items[%d] = [%d, %f, %d, %hd]\n", i, items[i].ID, items[i].weight, items[i].stockCount, items[i].colors);
    }

    printf("items with color 123 = %d\n", countWithColors(items, 123));
    freeArray(items);
}
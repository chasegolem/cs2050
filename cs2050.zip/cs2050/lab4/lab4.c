#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"

/**
Chase Golem (cdg2mz)
22 September 2023
Lab 4
CS_2050
*/

/**
Make the array with the number of elements and the size of the elements from typeof().
*/
void * makeArray(int arraySize, int elementSize){
    if(elementSize > 0 && arraySize > 0){
        // Free extra space to store the arraySize in the beginning
        int* array;
        if((array = malloc(sizeof(int) + (arraySize * elementSize)))){
            array[0] = arraySize;
            // Return with the pointer +1 to allow normal use of the array.
            array = array+1;
            return((void*)(array));
        } else {
            return NULL;
        }
    } else {
        return NULL;
    }
}

/**
Get the size of the array.
*/
int getSize(void *array){
    if(array){
        // Use -1 as an index due to the arithmetic in makeArray().
        return(((int*)array)[-1]);
    } else {
        return -1;
    }
}

/**
Return the amount of elements with a certain color. Self explainatory.
*/
int countWithColors(InventoryItem *items, short colorCount){
    int count = 0;
    // Use getSize() to get the correct size of the array.
    for(int i = 0; i < getSize(items); i++){
        if(items[i].colors == colorCount){
            count++;
        }
    }

    return count;
}

/**
Free the array from memory.
*/
void freeArray(void *array){
    if(array){
        // -1 is used because of the arraySize int in the beginning.
        free(((int*)array-1));
    }
}
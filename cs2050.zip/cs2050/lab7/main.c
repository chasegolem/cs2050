#include <stdio.h>
#include "lab7.h"

int main(void){
    Stack *head = initStack();
    if(head){
        for(int i = 1; i <= 10; i++){
            printf("Adding %d... ", i);
            if(pushStack(head, &i) == 0){
                printf("Added. New size = %d.. ", getSize(head));
                printf("Top data = %p\n", peekStack(head));
            } else {
                printf("Failed. \n");
            }
        }
        
        for(int i = 0; i < 10; i++){
            printf("Removing %d... ", i);
            void* data = popStack(head);
            printf("%p removed. New size = %d\n", data, getSize(head));
        }

        freeStack(head);
    } else {
        printf("Returned NULL\n");
    }
}
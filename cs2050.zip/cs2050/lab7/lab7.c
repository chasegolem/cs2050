#include <stdio.h>
#include <stdlib.h>
#include "lab7.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050
 * Lab 7
 * 13 October 2023
*/

typedef struct _Info Info;

typedef struct _Stack Stack;

struct _Info {
    Info *next;
    void *data;
};

struct _Stack {
    Info *info;
};

// O(1)
// Creates a stack structure with an Info structure inside it,
// because for some reason that makes any sense?
Stack * initStack(){
    Stack *head = malloc(sizeof(Stack));
    if(head){
        Info *info = malloc(sizeof(Info));
        if(info){
            info->data = NULL;
            info->next = NULL;
            head->info = info;
            if(head->info != NULL){
                return head;
            } else {
                return NULL;
            }
        } else {
            return NULL;
        }
    } else {
        return NULL;
    }
}

// O(1)
// Return the number of elements in the Stack, or
// more accurately, the Info nodes.
// (who's idea was this?)
int getSize(Stack * s){
    if(s){
        int count = 0;
        Info *p = s->info;
        while(p->next != NULL){
            count++;
            p = p->next;
        }
        return count;
    } else {
        return 0;
    }
}

// O(1)
// Get the data for the first Info structure on the Stack.
void * peekStack(Stack * s){
    if(s){
        Info *info = s->info;
        if(info){
            return info->data;
        } else {
            return NULL;
        }
    } else {
        return NULL;
    }
}

// O(1)
// Add an Info node to the top of the stack, setting the current
// top as a child of the new Info node.
int pushStack(Stack * s, void *data){
    int ec = 1;
    if(s){
        Info *info = malloc(sizeof(Info));
        if(info){
            info->data = data;
            info->next = s->info;
            s->info = info;
            if(s->info){
                ec = 0;
            }
        }
    }
    return ec;
}

// O(1)
// Remove the Info node on the top of the stack.
void * popStack(Stack * s){
    Info *p = s->info;
    void* data = p->data;
    s->info = p->next;
    free(p);
    return data;
}

// O(n)
// Check for an Info node that has the same data as
// whatever is in the parameter.
int stackContains(Stack * s, void *data){
    int ec = 1;
    Info *p = s->info;
    while(p->next){
        if(p->data == data) ec = 0;
        p = p->next;
    }
    return ec;
}

// O(n)
// Free the stack, basically a useless function and
// a waste of a few seconds.
void freeStack(Stack * s){
    free(s);
}

// i mean this in the most polite way, but what the hell was this lab.
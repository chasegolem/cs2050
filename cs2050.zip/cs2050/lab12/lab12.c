#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include "lab12.h"

/**
 * Chase Golem (cdg2mz)
 * CS2050
 * 1 December 2023
 * Lab 12
 */

struct _Heap {
    int key;
    Employee eData;
    int size;
    PHeap left;
    PHeap right;
};

// Make a heep object and return it.
PHeap HeapConstruct()
{
	PHeap heap = malloc(sizeof(PHeap));
    return heap;
}

// I couldn't figure this one out.
int HeapInsert(PHeap heap, int key, void * inputData)
{
	if(heap && key){
        PHeap h = malloc(sizeof(PHeap));
        h->key = key;
        heap->size++;
        return 0;
    }
    return -1;
}

// Find the lowest heap key and delete it. Sorts through the
// entire array or whatever. Concept from CS2050 notes by Jim Ries.
int HeapDelete(PHeap heap, void ** outputData)
{
	if(heap){
        int min = heap->key;
        if(heap->left != NULL && heap->right != NULL){
            free(heap);
            return min;
        }
        heap->size--;
        if(heap->left == NULL){
            heap->key = HeapDelete(heap->right, outputData);
        } else if(heap->right == NULL){
            heap->key = HeapDelete(heap->left, outputData);
        } else {
            if(heap->left->key < heap->right->key){
                heap->key = HeapDelete(heap->left, outputData);
            } else {
                heap->key = HeapDelete(heap->right, outputData);
            }
        }
        return min;
    }
    return -1;
}

// Free it.
void HeapDestruct(PHeap heap)
{
    free(heap);
}
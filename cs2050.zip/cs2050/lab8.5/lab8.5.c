#include <stdio.h>
#include <stdlib.h>
#include "lab8.5.h"

// for negative powers
double negmypow(int base, int power){
    return 1/mypow(base, -1*power);
}

// return the base^power, or attempt to
double mypow(int base, int power)
{
    if(power >= 1){
        return base*mypow(base, power - 1);
    } else if(power <= -1){
        return negmypow(base, power);
    } else {
        return 1;
    }

}


void PrintBaseBallPlayers(PBaseBallPlayer players, int length)
{
    if(length > 0){
        PrintBaseBallPlayer(players);
        PrintBaseBallPlayers(Next(players), length-1);
    }
}

PBaseBallPlayer FindHighestAvg(PBaseBallPlayer player, int length){
    PBaseBallPlayer temp = player;
    if(length > 0){
        if(AVG(temp) < AVG(Next(temp))) temp = Next(temp);
        return FindHighestAvg(temp, length -1);
    }
    return temp;
}

void SortBaseBallPlayers(PBaseBallPlayer players, int length)
{
    PBaseBallPlayer highest = FindHighestAvg(players, length);
    if(length > 0){
        PrintBaseBallPlayer(highest);
    }
}

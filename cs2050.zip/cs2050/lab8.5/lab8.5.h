#ifndef _LAB8_5_H
#define _LAB8_5_H

#include "baseball.h"

// Implement this function for the lab grade
double mypow(int base, int power);

// Implement one or both of these for extra credit
void PrintBaseBallPlayers(PBaseBallPlayer players, int length);
void SortBaseBallPlayers(PBaseBallPlayer players, int length);



#endif
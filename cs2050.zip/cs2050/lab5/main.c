#include <stdio.h>
#include "lab6.h"

int main(void){
    Node *list = NULL;
    makeList(&list);

    printf("size = %d\n", getSize(list));
    for(int i = 0; i < 10; i++){
        int ec = insertAtHead(&list, (void*)(&i));
        printf("error code when creating = %d\n", ec);
    }
    printf("list = %p\n", list->data);
    printf("size = %d\n", getSize(list));
    for(int i = 0; i < getSize(list); i++){
        void* data = removeFromTail(&list);
        printf("removed at %d = %p\n", i, data);
    }
    /**freeList(&list);*/
    
}
#include <stdio.h>
#include "lab5.h"

int main(void){
    List* head;
    int ec = 0;
    head = initList(&ec);
    printf("head = %d\n", head->object);
    if(ec == 0){
        for(int i = 0; i < 99; i++){
            head = insertAtHead(i, head, &ec);
        }
        printf("list length = %d\n", getListLength(head));
        for(int i = 1; i < 100; i++){
            int data = getAtIndex(i, head);
            printf("List[%d] = %d\n", i, data);
        }
        freeList(head);
    }
}
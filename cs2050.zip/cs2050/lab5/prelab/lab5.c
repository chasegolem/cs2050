#include <stdio.h>
#include <stdlib.h>
#include "lab5.h"

List * initList(int* state){
    List *head = malloc(sizeof(List));
    if(head){
        head->object = 0;
        head->next = NULL;
        *state = 0;
        return(head);
    } else {
        *state = 1;
        return NULL;
    }
}

List * insertAtHead(int data, List* head, int* state){
    List* node;
    node = malloc(sizeof(List));
    if(node){
        node->object = data;
        node->next = head;
        *state = 0;
        return node;
    } else {
        *state = 1;
        return NULL;
    }
}

int getAtIndex(int index, List* head){
    List* pointer = head;
    for(int i = 0; i < index; i++){
        pointer = pointer->next;
    }
    return pointer->object;
}

int getListLength(List* head){
    int count = 1;
    while(head->next != NULL){
        head = head->next;
        count++;
    }
    return count;
}

List * freeList(List* head){
    free(head);
    return NULL;
}
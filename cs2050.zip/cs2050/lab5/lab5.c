#include <stdio.h>
#include <stdlib.h>
#include "lab5.h"

/**
 * Chase Golem (cdg2mz)
 * 29 September 2023
 * Lab 5
 * CMP_SC 2050
*/

int makeList(Node **list){
    *list = NULL;
    return 0;
}

int getSize(Node *list){
    if(list == NULL){
        return 0;
    } else {
        Node *pointer = list;
        int count = 0;
        while(pointer->next != NULL){
            count++;
            pointer = pointer->next;
        }
        return count;
    }
}

int insertAtHead(Node **list, void *data){
    Node *temp = malloc(sizeof(Node));
    if(temp){
        temp->data = data;
        temp->next = *list;
        *list = temp;
        return 0;
    } else {
        return 1;
    }
}

void * removeFromTail(Node **list){
    if(getSize(*list) == 1){
        *list = NULL;
        return NULL;
    } else {
        Node *pointer = *list;
        for(int i = 0; i < getSize(*list)-1; i++){
            pointer = pointer->next;
        }
        void* data = pointer->data;
        pointer->next = NULL;
        return(data);
    }
    
}

void freeList(Node **list){
    free(*list);
    *list = NULL;
}
#include <stdio.h>
#include <stdlib.h>
#include "lab8.h"

int main(void){
    PQueue pq = pqInit();
    if(pq){
        for(int i = 0; i < 10; i++){
            pqInsert(&i, i, pq);
            printf("size = %d\n", pqGetSize(pq));
        }
        for(int i = 0; i < 10; i++){
            printf("element %d = %p\n", i, pqPeek(pq));
        }
        for(int i = 0; i < 10; i++){
            printf("element %d = %p\n", i, pqRemoveMin(pq));
        }
        pqFree(pq);
    }
}
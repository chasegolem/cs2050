#include <stdio.h>
#include <stdlib.h>
#include "lab8.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050
 * 20 October 2023
 * Lab 8
*/

// In the words of Candace Flynn the Great, "I give up."

typedef struct _PQueue * PQueue;
typedef struct _Info Info;

struct _PQueue {
    Info* data;
    int ec;
};

struct _Info {
    void* data;
    int priority;
    Info* next;
};

// O(1)
// Returns the error code for the defined PQueue
int pqGetErrorCode(PQueue q){
    return q->ec;
}

// O(1)
// Initializes the PQueue parent element.
PQueue pqInit(){
    PQueue q = malloc(sizeof(PQueue));
    if(q){
        q->ec = 0;
        q->data = NULL;
        return q;
    } else {
        return NULL;
    }
}

// O(n)
// Insert the element at the priority given.
int pqInsert(void *data, int priority, PQueue q){
    int ec = 2;
    if(q){
        if(priority && priority > 0){
            if(data){
                if(q->data == NULL){
                  Info *info = malloc(sizeof(Info));
                    if(info){
                        info->data = data;
                        info->priority = priority;
                        q->data = info;
                    }
                    ec = 0;  
                } else {
                    Info *info = malloc(sizeof(Info));
                    if(info){
                        info->data = data;
                        info->priority = priority;
                        Info *p = q->data;
                        while(p->next && p->priority < priority) p = p->next;
                        info->next = p->next;
                        p->next = info;
                    }
                    ec = 0;
                }
            }
        }
        q->ec = ec;
        return ec;
    }
    return 2;
}

// O(1)
// Remove and return the value of the element(s) 
// with the least priority of the defined PQueue.
void * pqRemoveMin(PQueue q){
    if(q != NULL){
        if(q->data != NULL){
            Info *min = q->data;
            q->data = min->next;
            void* d = min->data;
            int priority = min->priority;
            free(min);
            q->ec = 0;
            if(q->data != NULL)
                if(q->data->priority == priority)pqRemoveMin(q);
            return d;
        } else {
            q->ec = 2;
            return NULL;
        }
    }
    return NULL;
}

// O(1)
// Return the first element of the defined PQueue.
void * pqPeek(PQueue q){
    int ec = 2;
    if(q){
        if(q->data->data){
            ec = 0;
            q->ec = 0;
            return q->data->data;
        } else {
            q->ec = ec;
            return NULL;
        }
    }
    return NULL;
}

// O(1)
// Returns the size of the defined PQueue.
int pqGetSize(PQueue q){
    int count = 0;
    if(q){
        if(q->data){
            for (Info *p = q->data; p->next != NULL; p = p->next){
                count++;
            }
        }
    }
    return count;
}

// O(n)
// Frees the defined PQueue.
void pqFree(PQueue q){
    free(q);
}
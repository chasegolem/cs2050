#include <stdio.h>
#include <stdlib.h>
#include "lab8.h"

// 0 = success, 1 = error
int ec = 0;

int pqGetErrorCode(PQueue pq){
	return ec;
}

PQueue pqInit(){
	PQueue *temp = malloc(sizeof(PQueue));
	temp->next = NULL;
	temp->data = NULL;
	temp->priority = NULL;
	return temp;
}

int pqInsert(void * data, int priority, PQueue pq){

}

void * pqReturnMax(PQueue){

}

int pqGetSize(PQueue){

}

void pqFree(PQueue){

}

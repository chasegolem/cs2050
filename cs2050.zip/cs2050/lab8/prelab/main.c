#include <stdio.h>
#include <stdlib.h>
#include "lab8.h"

int main(void){
	
}

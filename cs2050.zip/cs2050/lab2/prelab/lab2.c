#include <stdio.h>
#include <stdlib.h>
#include "lab2.h"

float *readFloatFileIntoArray(FILE *fptr, int *length){
	fscanf(fptr, "%d", length);
	printf("length: %d\n", *length);

	float* arr = malloc(*length*sizeof(float));
	if(arr){
		for(int i = 0; i < *length; i++){
			fscanf(fptr, "%f", &arr[i]);
		}
	}
	return arr;
}

void freeFloatArray(float **arr){
	free(*arr);
}

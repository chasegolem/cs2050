#ifndef _LAB2_H
#define _LAB2_H
// Prototypes
float * readFloatFileIntoArray(FILE * fptr, int *length);
void freeFloatArray(float **array);
#endif

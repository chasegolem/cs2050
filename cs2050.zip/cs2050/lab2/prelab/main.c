#include <stdio.h>
#include "lab2.h"

int main(int argc, char *argv[])
{
	if (2==argc)
	{
		FILE * fp = fopen(argv[1],"r");
		if (fp)
		{
			int len=0;
			float *a=readFloatFileIntoArray(fp,&len);
			for (int i=0;i<len && NULL!=a;i++)
			{
				printf("%f ",a[i]);
			}
			printf("\n");
			freeFloatArray(&a);
		}
	}
	else
	{
		fprintf(stderr,"Syntax: ./a.out filename\n");
	}
}


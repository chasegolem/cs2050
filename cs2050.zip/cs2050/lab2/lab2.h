#ifndef _LAB2_H
#define _LAB2_H
// Prototypes
int makeArray(int **array, int size);
void initArray(int *array, int size);
int multiplyEven(int *array, int size, int multiplicand);
void freeArray(int **array);
#endif

#include <stdio.h>
#include <stdlib.h>
#include "lab2.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050, Fall 2023
 * Lab 2
 * 8 September 2023
*/

int main(void){
    int size = 5;
    int *arr = malloc(size*sizeof(int));
    makeArray(&arr, size);
    initArray(arr, size);
    arr[0] = 5; arr[1] = 2; arr[2] = 3; arr[3] = 7; arr[4] = 8;
    for(int i = 0; i < size; i++){
        printf("arr[%d] = %d\n", i, arr[i]);
    }
    printf("\n");
    multiplyEven(arr, size, 2);
    for(int i = 0; i < size; i++){
        printf("arr[%d] = %d\n", i, arr[i]);
    }
    printf("\n");
    freeArray(&arr);
}
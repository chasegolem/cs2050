#include <stdio.h>
#include <stdlib.h>
#include "lab2.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050, Fall 2023
 * Lab 2
 * 8 September 2023
*/


int makeArray(int **array, int size){
    // free memory space for the array size
    *array = malloc(size*sizeof(int));
    // check if memory space has been made
    if(array){
        // success
        return 0;
    } else {
        // error
        return 1;
    }
}

void initArray(int *array, int size){
    // iterate through all the elements with size bounds
    for(int i = 0; i < size; i++){
        // set all elements in the array to 0
        array[i] = 0;
    }
}

int multiplyEven(int *array, int size, int multiplicand){
    // iterate through all the elements with size bounds
    for(int i = 0; i < size; i++){
        // check if even and muliply
        if(array[i] % 2 == 0) array[i] *= multiplicand;
    }
    return 0;
}

void freeArray(int **array){
    // free the memory to the OS
    free(*array);
}
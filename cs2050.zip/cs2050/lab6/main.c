#include <stdio.h>
#include <stdlib.h>
#include "lab6.h"

int main(void){
    Node *list = NULL;
    int ec = makeList(&list);
    if(ec == 0){
        printf("size = %d\n", getSize(list));
        for(int i = 0; i < 10; i++){
            printf("inserting %d... ", i);
            int ec2 = insertAtTail(list, &i);
            printf("error = %d, new size = %d\n", ec2, getSize(list));
        }
        printf("size = %d\n", getSize(list));

        for(int i = 0; i < 10; i++){
            printf("getting %d... ", i);
            void* data = getAtIndex(list, i);
            printf("got %p\n", data);
        }

        for(int i = 0; i < 10; i++){
            printf("removing %d... ", i);
            void* data = removeFromHead(list);
            printf("removed %p, new size = %d\n", data, getSize(list));
        }

    }
    freeList(&list);
}
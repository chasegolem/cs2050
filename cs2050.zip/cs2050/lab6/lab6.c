#include <stdio.h>
#include <stdlib.h>
#include "lab6.h"

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050
 * Lab 6
 * 6 October 2023
*/

/**
 * Make the head of the linked list by creating an empty dummy node
 * at the beginning. EC of 1 means failure, 0 is success.
*/
int makeList(Node **list){
    int ec = 1;
    if(!list){
        Node *temp = malloc(sizeof(Node));
        if(temp){
            temp->next = NULL;
            temp->data = NULL;
            *list = temp;
            ec = 0;
        }
        
    }
    return ec;
}

/**
 * Return the size of the linked list, skipping the head
 * of the list because it's irrelevant.
*/
int getSize(Node *list){
    int count = 0;
    if(list){
        Node *p = list;
        while(p->next != NULL){
            count++;
            p = p->next;
        }
    }
    return count;
}

/**
 * Get an element of the linked list at a certain place
 * in the list, as defined by index.
*/
void * getAtIndex(Node *list, int index){
    if(list && index >= 0 && index < getSize(list)){
        int count = 0;
        Node *p = list;
        while(count != index && p->next){
            count++;
            p = p->next;
        }
        return p->data;
    }
    return NULL;
}

/**
 * Insert an element at the tail of the linked list. An EC of 0 is success
 * while an EC of 1 is an error.
*/
int insertAtTail(Node *list, void *data){
    Node *p = list;
    int ec = 1;
    while(p->next) p = p->next;
    if(p && p->next == NULL){
        Node *temp = malloc(sizeof(Node));
        if(temp){
            temp->data = &data;
            temp->next = NULL;
            p->next = temp;
            if(p->next) ec = 0;
        }
    }
    return ec;
}

/**
 * Take the node from the head of the list, save the data, and 
 * free it to memory.
*/
void * removeFromHead(Node *list){
    if(getSize(list) > 0){
        if(list && list->next){
            Node *node = list->next;
            list->next = node->next;
            // Free the data.
            void* data = node->data;
            free(node);
            return data;
        }
    }
    return NULL;
}

/**
 * Free the remainder of the linked list.
*/
void freeList(Node **list){
    free(*list);
}
#include "lab11.h"
#include <stdio.h>

int main() 
{
	// Some simple attempts to use the BST to get you started
	BST * tree = initBST();
    if (tree)
	{
		for(int i = -10; i < 10; i++){
            insertBST(tree, i);
            printf("size = %d\n", getSizeBST(tree));
        }

        printf("inOrder = ");
		inOrderPrintBST(tree);
        printf("\n");

        printf("postOrder = ");
        postOrderPrintBST(tree);
        printf("\n");

        printf("min = %d\n", getMinBST(tree));
		freeBST(tree);
	}
}

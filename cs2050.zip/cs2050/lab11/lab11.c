#include <stdlib.h>
#include <stdio.h>
#include "lab11.h"

struct BST {
    int data;
    struct BST *right;
    struct BST *left;
};

/**
 * Chase Golem (cdg2mz)
 * CMPSC 2050
 * Lab 11
 * 10 November 2023
 */

// O(1)
BST * initBST()
{
	BST *tree = malloc(sizeof(BST));
    if(tree){
        // I'm not sure if this is needed but oh well.
        tree->left = NULL;
        tree->right = NULL;
        return tree;
    } else {
        return NULL;
    }
}

// Implementation is based on pseudocode from Ries notes, slide set 14.
BST* insert(BST *tree, int data){
    if(tree == NULL){
        BST *node = malloc(sizeof(BST));
        node->data = (int)data;
        node->right = NULL;
        node->left = NULL;
        return node;
    } else {
        if(!tree->data){
            // Honestly, I don't know why this works but don't fix what isn't broken.
            *tree = *insert(NULL, data);
        } else if(tree->data > data){
            tree->left = insert(tree->left, data);
        } else if(tree->data < data) {
            tree->right = insert(tree->right, data);
        }
    }
    return tree;
}

// O(log(n))
// This is basic enough to not need comments.
// 0 indicates success, 1 indicates failure
int insertBST(BST *tree, int data)
{
    if(tree){
        insert(tree, data);
        return 0;
    } else {
        return 1;
    }
}

// O(1)
// This is based off implementation I learned in high school.
int getSizeBST(BST *tree)
{
    if(tree){
        getSizeBST(tree->left);
        getSizeBST(tree->right);
        return getSizeBST(tree->left) + getSizeBST(tree->right) + 1;
    } else {
        return 0;
    }
}

// O(log(n))
// This implementation was based off a lot of guessing.
int getMinBST(BST *tree)
{
    if(tree->left == NULL){
        return tree->data;
    } else {
        return getMinBST(tree->left);
    }
}

// O(n)
// Implementation was pulled from Ries notes, slide set 14.
void postOrderPrintBST(BST *tree)
{
    if(tree){
        postOrderPrintBST(tree->left);
        postOrderPrintBST(tree->right);
        printf("%d ", tree->data);
    }
}

// O(n)
// Implementation was pulled from Ries notes, slide set 14.
void inOrderPrintBST(BST *tree)
{
    if(tree){
        inOrderPrintBST(tree->left);
        printf("%d ", tree->data);
        inOrderPrintBST(tree->right);
    }
}

// O(n)
// Implementation was pulled from Ries notes, slide set 14.
void freeBST(BST *tree)
{
    if(tree){
        freeBST(tree->left);
        freeBST(tree->right);
        free(tree);
    }
}


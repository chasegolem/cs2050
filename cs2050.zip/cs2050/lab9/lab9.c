#include "lab9.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/**
 * Chase Golem (cdg2mz)
 * CMP_SC 2050
 * Lab 9
 * 3 November 2023
 */

// Make the array with the specified size and elements size.
void * makeArray(int arraySize, int elementSize) 
{
    int *arr = malloc((arraySize * elementSize) + sizeof(int));
    if(arr){
        arr[0] = arraySize;
        arr++;
        return((void*)arr);
    }
	return NULL;
}

// Return the size of the array, which was hidden behind it.
int getSize(void *array) 
{
	return(((int*)array)[-1]);
}

// Free the array.
void freeArray(void *array) 
{
    if(array){
        free((int*)array-1);
    }
}

// Compare the clock speeds of the two computers, Computer B is
// usually the one being searched.
int compareComputersByClockSpeed(Computer *a, Computer *b) 
{
	if(a && b){
        if(a->fltClockSpeed > b->fltClockSpeed){
            return -1;
        } else if(a->fltClockSpeed < b->fltClockSpeed){
            return 1;
        } else {
            return 0;
        }
    } else {
        return -1;
    }
}

// Easy enough.
int compareComputersByCompanyAndModel(Computer *a, Computer *b) 
{
    int compCompare = strcmp(a->sCompany, b->sCompany);
    if(compCompare > 0){
        return 1;
    } else if(compCompare < 0){
        return -1;
    } else if(compCompare == 0){
        int modCompare = strcmp(a->sModel, b->sModel);
        if(modCompare > 0){
            return 1;
        } else if(modCompare < 0){
            return -1;
        } else {
            return 0;
        }
    } else {
        return compCompare;
    }
}

// Used my own because the provided function wasn't the best, and this is
// what I already knew from past experiences with binary sorting.
int binarySearchClockSpeed(Computer *array, Computer *query, int left, int right){
    while(left <= right){
        int midpoint = left + (right - left)/2;
        switch(compareComputersByClockSpeed(&array[midpoint], query)){
            case 1: {
                left = midpoint + 1;
                break;
            }
            case -1: {
                right = midpoint - 1;
                break;
            }
            case 0: {
                return midpoint;
                break;
            }
        }
    }
    return -1;
}

// Same binary search function as above, but using the company
// and model fields.
int binarySearchModel(Computer *array, Computer *query, int left, int right){
    while(left <= right){
        int midpoint = left + (right - left)/2;
        switch(compareComputersByCompanyAndModel(&array[midpoint], query)){
            case 1: {
                left = midpoint + 1;
                break;
            }
            case -1: {
                right = midpoint - 1;
                break;
            }
            case 0: {
                return midpoint;
                break;
            }
        }
    }
    return -1;
}

// Yea!
int searchComputersByClockSpeed(Computer *array, Computer *query) 
{
    if(array && query){
        return binarySearchClockSpeed(array, query, 0, getSize(array));
    } else {
        return -1;
    }
}

// Didn't feel like doing this.
int searchComputersByCompanyAndModel(Computer *array, Computer *query) 
{
	if(array && query){
        return binarySearchModel(array, query, 0, getSize(array));
    } else {
        return -1;
    }
}
#include "lab9.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int printRandoms(int lower, int upper, int count){
    int i;
    int num;
    for (i = 0; i < count; i++) {
        num = (rand() % (upper - lower + 1)) + lower;
    }
    return num;
}

int main() 
{
    srand(time(0));
    char company[6][64] = {"Dell", "HP", "Apple", "Acer", "Google", "Samsung"};
    char model[8][64] = {"Inspiron", "Macbook Pro", "Macbook Air", "Chromebook", "Inspire", "idfk", "Some other BS Model", "iPad"};

    Computer *array = makeArray(100, sizeof(Computer));
    for(int i = 0; i < 100; i++){
        Computer *t = malloc(sizeof(Computer));
        t->fltClockSpeed = (float)i;
        t->iDisk = i+1;
        t->iMemory = i + 2;
        strcpy(t->sCompany, company[printRandoms(0, 5, 1)]);
        strcpy(t->sModel, model[printRandoms(0, 7, 1)]);
        array[i] = *t;
    }

    for(int i = 0; i < 100; i++){
        Computer c = array[i];
        printf("Computer [%d] = make = %s, model = %s, clock = %lf, disk = %d, memory = %d\n", i, c.sCompany, c.sModel, c.fltClockSpeed, c.iDisk, c.iMemory);
    }

    Computer searchC;
    searchC.fltClockSpeed = 65;
    strcpy(searchC.sCompany, company[printRandoms(0, 5, 1)]);
    strcpy(searchC.sModel, model[printRandoms(0, 7, 1)]);
    int search = searchComputersByClockSpeed(array, &searchC);
    printf("Search computer = company = %s, model = %s, clock = %lf\n", searchC.sCompany, searchC.sModel, searchC.fltClockSpeed);
    printf("Found computer [%d]\n", search);

    int searchCi = searchComputersByCompanyAndModel(array, &searchC);
    printf("Found computer [%d]\n", searchCi);

    freeArray(array);
    return 0;
}












































#include <stdio.h>
#include "lab3.h"

int main(void){
    void *array = createArray(10,10);
    printf("arraySize: %d\n", getArraySize(array));
    //freeArray(array);
}
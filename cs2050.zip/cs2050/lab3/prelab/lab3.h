#ifndef _LAB3_H
#define _LAB3_H

void *createArray(int, int);
int getArraySize(void *);
void freeArray(void *);

#endif
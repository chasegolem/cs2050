#include <stdio.h>
#include <stdlib.h>
#include "lab3.h"

void *createArray(int arraySize, int dataSize){
    int *array;
    array = malloc(arraySize * dataSize+sizeof(int));
    array[0] = arraySize;
    return((void*)(array+1));
}

int getArraySize(void *array){
    return (((int*)array)[-1]);
}

void freeArray(void *array){
    free(array);
}
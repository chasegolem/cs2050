#ifndef _LAB3_H
#define _LAB3_H
// Prototypes
char * strAlloc(int);
int strLen(char *);
void strCpy(char *, char *);
int strRev(char *, char *);
void strFree(char *);
#endif

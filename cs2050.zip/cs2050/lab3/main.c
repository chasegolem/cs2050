#include <stdio.h>
#include <stdlib.h>
#include "lab3.h"

int main(void){
    char *string = strAlloc(5);
    string[0] = 'H'; string[1] = 'E'; string[2] = 'L'; string[3] = 'L'; string[4] = 'O';

    printf("strLen = %d\n", strLen(string));
    for(int i = 0; i < strLen(string); i++){
        printf("string[%d] = %c\n", i, string[i]);
    }

    char *newString = strAlloc(10);
    strCpy(newString, string);
    for(int i = 0; i < strLen(newString); i++){
        printf("newString[%d] = %c\n", i, newString[i]);
    }

    char *stringReversed = strAlloc(10);
    switch(strRev(stringReversed, string)){
        case -1: 
            printf("Error\n");
            break;
        case 0:
            printf("Arrays not the same size\n");
            for(int i = 0; i < strLen(stringReversed); i++){
                printf("stringReversed[%d] = %c\n", i, stringReversed[i]);
            }
            break;
        case 1:
            printf("Arrays are the same size\n");
            for(int i = 0; i < strLen(stringReversed); i++){
                printf("stringReversed[%d] = %c\n", i, stringReversed[i]);
            }
            break;
    }

    strFree(string);
    strFree(newString);
    strFree(stringReversed);
    
}
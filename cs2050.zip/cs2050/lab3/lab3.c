#include <stdio.h>
#include <stdlib.h>
#include "lab3.h"

/**
 * Chase Golem (cdg2mz)
 * 15 September 2023
 * CMP_SC 2050
 * Lab 3
*/

/**
 * Allocate array with malloc() with array size in the beginning.
*/
char * strAlloc(int size){
    // Allocate the array, and add extra space for an int for the array size.
    int *arr = malloc(sizeof(int) + (size * sizeof(char)));
    arr[0] = size;
    if(arr){
        // Returning the array like this will allow the user to interact with the array as normal.
        return((char*)(arr+1));
    } else {
        return NULL;
    }
}

/**
 * Return the array size, which is found at the -1 index because of
 * arithmetic in strAlloc().
*/
int strLen(char *str){
    return (((int*)str)[-1]);
}

/**
 * Copy the source array into the dest array. This will only work if the
 * destination array is the same, or larger than, the source array.
*/
void strCpy(char *dest, char *source){
    if(strLen(dest) >= strLen(source)){
        for(int i = 0; i < strLen(source); i++){
            dest[i] = source[i];
        }
    }
}

/**
 * Basically like strCpy(), but put the source array into reverse. Will only
 * work if the destination array is the same, or larger than, the source array.
 * -1 for error, 0 for different sizes and 1 for the same array size.
*/
int strRev(char *dest, char *source){
    if(strLen(dest) >= strLen(source)){
        int end = strLen(source);

        for(int i = 0; i < strLen(source)+1; i++){
            dest[i-1] = source[end];

            // Inverse of index is size - i - 1.
            end = strLen(source) - i - 1;
        }

        if(strLen(dest) == strLen(source)){
            return 1;
        } else {
            return 0;
        }
    } else {
        return -1;
    }
}

/**
 * Free the array, excluding the int at the beginning to avoid heap errors.
*/
void strFree(char *str){
    free(str-sizeof(int));
}